# MyAssistant

A voice assistant app made in Flutter and Next.js

## Collaborators

1. Soumyaneel Sarkar (@A-Little-Hat)
2. Vishal Kumar Paswan (@vishal-kumar-paswan)
