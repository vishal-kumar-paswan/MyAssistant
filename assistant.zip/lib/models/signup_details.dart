class SignUpDetails {
  
}